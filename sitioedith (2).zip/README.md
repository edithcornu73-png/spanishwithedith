# Spanish with Edith

Proyecto listo para desplegar en Vercel.

Instrucciones rápidas:

1. Subir a GitHub o comprimir y desplegar directamente en Vercel.
2. Instalar dependencias: `npm install`.
3. Ejecutar en local: `npm run dev`.

El sitio detecta idioma según el navegador y está configurado para no segmentarse en Argentina.
